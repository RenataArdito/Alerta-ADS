package com.grupo1.alerta.services;

@Service
public class LoginService {

    @Autowired
    private LoginRepo loginRepo;

    public boolean validarLogin(String email, String senha) {
        return loginRepo.findByEmailAndSenha(email, senha).isPresent();
    }
}