package com.grupo1.alerta;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AlertaApplication {

	public static void main(String[] args) {
		SpringApplication.run(AlertaApplication.class, args);
	}

}
