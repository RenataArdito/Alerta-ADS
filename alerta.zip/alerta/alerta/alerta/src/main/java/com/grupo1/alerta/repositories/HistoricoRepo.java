package com.grupo1.alerta.repositories;

import org.springframework.data.repository.CrudRepository;

public interface HistoricoRepo extends CrudRepository<Historico, Long> {
    
}