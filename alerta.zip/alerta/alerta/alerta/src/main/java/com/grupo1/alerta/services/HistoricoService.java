package com.grupo1.alerta.services;

@Service
public class HistoricoService {

    @Autowired
    private HistoricoRepo historicoRepo;

    public void salvarHistorico(Historico historico) {
        historicoRepo.save(historico);
    }

    public List<Historico> listarHistoricos() {
        return (List<Historico>) historicoRepo.findAll();
    }
}